package Finance;
import Database.myJDBC;
import java.sql.*;

public abstract class management {
    public static double Total_E=0;
    public static double Total_R=0;

    public void view(){

    }

    public void cal(){

    }

}
