package Permission;

public interface SalesHeadPermissions extends GeneralPermission{
    void updateSalesEmployee();
    void viewSalesRevenue();
    void removeProduct();


}
