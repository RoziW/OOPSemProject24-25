package Permission;

public interface GeneralPermission {

        void viewEmployeeInfo(String department);

}
