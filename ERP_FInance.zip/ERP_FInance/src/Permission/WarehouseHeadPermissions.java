package Permission;

public interface WarehouseHeadPermissions extends GeneralPermission{
    void updateWarehouseEmployee();
    void viewWarehouseExpenses();
    void addProduct();
}
