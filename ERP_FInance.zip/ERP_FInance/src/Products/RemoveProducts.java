package Products;

import Database.myJDBC;
import java.sql.*;
import java.sql.PreparedStatement;
import java.util.Scanner;
public class RemoveProducts extends viewProducts {

    @Override
    public void viewAllProduct() {
        super.viewAllProduct(); // Call to view all products before removing one
    }

    public RemoveProducts() {
    }

    public void RemoveP(int product_id, int userId) {
        Scanner input = new Scanner(System.in);
        int quantity;
        // Variables for product data
        String productName = "";
        double amount = 0.0;
        String department = "";
        int availableQuantity = 0;

        // Prepare SQL query to get the product details before deletion
        String selectQuery = "SELECT product_name, product_quantity, amount, department FROM products WHERE product_id = ?";

        try {
            // Begin transaction to ensure both updates are executed atomically
            myJDBC.connection.setAutoCommit(false);

            // Prepare and execute the select query
            PreparedStatement selectStmt = myJDBC.connection.prepareStatement(selectQuery);
            selectStmt.setInt(1, product_id);
            ResultSet resultSet = selectStmt.executeQuery();

            // If product exists, get the product details
            if (resultSet.next()) {
                productName = resultSet.getString("product_name");
                amount = resultSet.getDouble("amount");
                availableQuantity = resultSet.getInt("product_quantity");
                department = resultSet.getString("department");
                System.out.println("Enter the quantity you want to remove: ");
                quantity = input.nextInt();

                while (quantity > availableQuantity) {
                    System.out.println("Enter a valid quantity: ");
                    quantity = input.nextInt();
                }

                if (quantity <= availableQuantity) {
                    // Update the product quantity in the database
                    int updatedQuantity = availableQuantity - quantity;
                    String updateQuery = "UPDATE products SET product_quantity = ? WHERE product_id = ?";
                    int rowsAffected = myJDBC.executePreparedUpdate(updateQuery, updatedQuantity, product_id);

                    // Only proceed if product quantity was updated successfully
                    if (rowsAffected > 0) {
                        // Insert the transaction into the revenue table
                        double totalAmount = amount * quantity;
                        java.sql.Date currentDate = new java.sql.Date(System.currentTimeMillis());
                        String expenseQuery = "INSERT INTO revenue (user_id, amount, department, date) VALUES (?, ?, ?, ?)";
                        // Insert expense record
                        PreparedStatement expenseStatement = myJDBC.connection.prepareStatement(expenseQuery);
                        expenseStatement.setInt(1, userId); // Set user_id
                        expenseStatement.setDouble(2, totalAmount);  // Set dept_id (Warehouse)
                        expenseStatement.setString(3, department); // Set the amount (price of the product)
                        expenseStatement.setDate(4, currentDate); // Set the current date

                        // Execute the expense insert query
                        int revenueRowsAffected = expenseStatement.executeUpdate();
                        if (revenueRowsAffected > 0) {
                            System.out.println("Expense record added successfully!");

                        } else {
                            System.out.println("Failed to add expense record.");
                        }
                    }
                }

            } else {
                System.out.println("Product ID not found.");
            }
        }
                catch (SQLException e) {
                e.printStackTrace();
            }
        }



    // Method to get the department ID based on the department associated with the product
    private int getDeptId(String department) {
        int deptId = 0;
        try {
            String deptQuery = "SELECT dept_id FROM department WHERE department = ?";
            PreparedStatement preparedStatement = myJDBC.connection.prepareStatement(deptQuery);
            preparedStatement.setString(1, department);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                deptId = resultSet.getInt("dept_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return deptId;
    }
}
